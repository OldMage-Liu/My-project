# 统计断点文件中的进度
with open('二级数据.txt', 'r', encoding='utf-8') as f:
    all_lines = [line.strip() for line in f if line.strip()]
    unique_ids = set(all_lines)

print(f'文件中总行数: {len(all_lines)}')
print(f'去重后的唯一ID数: {len(unique_ids)}')
print(f'重复次数: {len(all_lines) - len(unique_ids)}')
